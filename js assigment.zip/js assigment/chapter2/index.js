var userName = " Welcome sana";
alert( userName);

var userName = "sana rajput";
alert( userName);

var userName = "Hello World";
alert( userName);

var userName = "sana rajput";
alert( userName);

var age = "17 years old";
alert(age);

var work = "certified mobile application development";
alert(work);

var food = "Pizza\nPizz\nPiz\nPi\nP";
alert( food);

var userName = "My email address is example@example.com";
alert( userName);


var userName = "I am try to learn from the book A smarter\n way to learn Javascript";
alert( userName);

document.write("Yah! i can write HTML content through Javascript")

var userName =" “▬▬▬▬▬▬▬▬▬ஜ۩۞۩ஜ▬▬▬▬▬▬▬▬▬”";
alert( userName);
