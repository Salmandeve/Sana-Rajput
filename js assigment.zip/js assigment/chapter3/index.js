alert("I am 15 years old");
alert("You have visited this site 14 times");
document.write("My birth year is 1990<br> Data type of my declared variable is number");

document.write("<br>")
var visitorName = "John Doe";
var productTitle = "Tshirt";
var Quantity = "5";
document.write(visitorName + " order " +  Quantity  +   productTitle  + " (s) on XYZ clothing store ");
