var a,b,c;
var letter,digits,underscore,dollar,number;
var If,Else,Const,lrt,erray;
 
document.write("variable names can only contain,numbers,$and_.For example : $my_1stVariable.<br> Variables must begin with a letter,$ or_.For example : $name,_ name or name <br>Variable names are  case sensitive <br>Variable names should not be JS keywords<br>")
