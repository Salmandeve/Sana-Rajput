var num = 3;
var newNum =5;
document.writeln("Sum of " ,+num+ '+' +newNum +'=' + (num+newNum));

document.write("<br>")
var num = 5;
var newNum = 3;
document.write("Sum of " ,+num+ '-' +newNum +'=' + (num-newNum));

document.write("<br>")
var num = 3;
var newNum = 5;
document.write("Sum of " ,+num+ '*' +newNum +'=' + (num*newNum));

document.write("<br>");
var num = 3;
var newNum = 5;
document.write("Sum of " ,+num+ '/' +newNum +'=' + (num/newNum));

document.write("<br>");
document.write("<br>");
document.write("<hr>");
document.write("<h1> Q3</h1>");
var x;
document.write("value after variable for declaration is undefined");


document.write("<br>");

document.write("Initial value:"+num+"<br>");
num++;
document.write("value after increment is:"+num+"<br>");
num+=7;
document.write(" value after addition is:"+num+"<br>");
num--;
document.write("value after decrement is:"+num+"<br>");
var remainder=num%3;
document.write("The remainder is;"+ remainder +"<br>");
var ticketPr=1000;
var totalC=ticketPr*5;
// document.write("The cost of buying 5 movie tickets is:" + totalC+"PKR<br>");
// var item1P=780;
// var item1Q=2;
// var item2P=50;
// var item2Q=3;
// var shippingCharge=50;
// var totalItemscost=(item1P*item1Q)+(item2P*item2Q);
// var totalcost=totalItemscost + shippingCharges;
// document.write("Item 1 Price: " + item1Price + "<br>");
// document.write("Item 1 Quantity: " + item1Q + "<br>");
// document.write("Item 2 Price: " + item2P + "<br>");
// document.write("Item 2 Quantity: " + item2Q + "<br>");
// document.write("Shipping Charges: " + shippingCharges + "<br>");
// document.write("Total Cost: " + totalCost);

document.write("<hr>")
document.write("<br>")
document.write("<h1>Q4</h1>")
var num = 5;
var newNum = 300;
document.write("Total cost to buy " , + num + ' tickets to a movie is ' +newNum + 'PKR');

document.write("<hr>")
document.write("<br>")
document.write("<h1>Q5</h1>")

var number = prompt("Enter a number!!");
var result;
for( var i=1; i<= 10; i++)
{ 
result =  number * i;
document.write(number + "x" + i + "=" + result + "<br/>")
}
var a = 2, b = 1;
var result = --a - --b + ++b + b--;

document.write("<hr>")
document.write("<br>")
document.write("<h1>Q6</h1>")
var num = 25;
var newNum = 77;
document.write( num + ' is ' +newNum );
document.write("<br>")
var num = 70;
var newNum = 21.1111111111111111;
document.write( num + ' is ' +newNum );

document.write("<hr>")
document.write("<br>")
document.write("<h1>Q7</h1>")

var num = 1;
var newNum = 650;
document.write("Price of items " , + num + ' is ' +newNum );
document.write("<br>")
var num = 1;
var newNum = 3;
document.write("Quantity of item " , + num + ' is ' +newNum );
document.write("<br>")
var num = 2;
var newNum = 100;
document.write("Price of items " , + num + ' is ' +newNum );
document.write("<br>")
var num = 2;
var newNum = 7;
document.write("Quantity of items " , + num + ' is ' +newNum );
document.write("<br>")
var num = 1;
document.write("Shiping charges " , + num  );
document.write("<br>");
document.write("<br>")

var num = 2750;
document.write("Total cost of your order " , + num  );



document.write("<hr>")
document.write("<br>")
document.write("<h1>Q8</h1>")

var num = 980;
var newNum = 650;
document.write("Total marks : " , + num );
document.write("<br>")

var num = 804;
var newNum = 650;
document.write("Marks obtained : " , + num );
document.write("<br>")

var num = 82.0408165306;
var newNum = 650;
document.write("percentage : " , + num + "%"  );
document.write("<br>")


document.write("<hr>")
document.write("<br>")
document.write("<h1>Q9</h1>")

var num = 1748;
var newNum = 650;
document.write("Total currency in PKR : " , + num );
document.write("<br>")

document.write("<hr>")
document.write("<br>")
document.write("<h1>Q11</h1>")

var num = 2016;
var newNum = 650;
document.write("Current year : " , + num );
document.write("<br>")
var num = 1992;
var newNum = 650;
document.write("Birth year : " , + num );
document.write("<br>")

var num = 24;
var newNum = 650;
document.write("your age is : " , + num );
document.write("<br>")
document.write("<hr>")

document.write("<h1>Q12</h1>")
document.write("<br>")

var num = 20;
var newNum = 650;
document.write("Radius of a circle : " , + num );
document.write("<br>")
var num = 125.679999999999;
var newNum = 650;
document.write("The circumference is : " , + num );
document.write("<br>")

var num = 1256.8;
var newNum = 650;
document.write("The area is : " , + num );
document.write("<br>")
document.write("<hr>")

document.write("<h1>THE LIFE TIME SUPPLY CALCULATORS</h1>")
document.write("<h1>Q13</h1>")
document.write("<br>")



var num = 15;
var newNum = 650;
document.write("Current age : " , + num );
document.write("<br>")

var num = 65;
var newNum = 650;
document.write("Extimated maximun age : " , + num );
document.write("<br>")
var num = 3;
var newNum = 650;
document.write("Ammount of snacks per day : " , + num );
document.write("<br>")

var num = 150;
var newNum = 65;
document.write("You will need "  + num + " cocalte chip to last you until the ripe old age of 65" );
document.write("<br>")






















