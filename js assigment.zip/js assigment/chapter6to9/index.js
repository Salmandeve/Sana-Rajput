document.write("<h1> Q1</h1>")
document.write("The value of a is 10")
var a = 10
document.write("<br>")
document.write(".......................................................")


document.write("<br>")
document.write("<br>")
document.write(" The value of++a is:",++a)
document.write(" <br>")
document.write("Know the value of a is:",+a)

document.write("<br>")
document.write("<br>")
document.write(" The value of++a is:",+a)
document.write(" <br>")
document.write("Know the value of a is:",++a)

document.write("<br>")
document.write("<br>")
document.write(" The value of--a is:",--a)
document.write(" <br>")
document.write("Know the value of a is:",a)

document.write("<br>")
document.write("<br>")
document.write(" The value of--a is:",a)
document.write(" <br>")
document.write("Know the value of a is:",--a)
document.write("<hr>")


document.write("<h1> Q2</h1>")
document.write("a is ?")
document.write("<br>")
document.write("b is ?")
document.write("<br>")
document.write("result is ?")


document.write("<h1> Q3</h1>")
document.write("<h2> Alerts</h2>")
alert("Thanks for your input")
alert("Sana Rajput")














